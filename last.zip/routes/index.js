const express = require('express')
const app = express()
const userControler = require ('../controller/userController')
const {userValidationResult, vaidate,validationResulltUpdate,validationResultPost} = require('../medelwhere/vaedetor')
const User = require('../models/user')
const isLoggedIn = require('../medelwhere/authentection')
const upload = require('../medelwhere/uplaud')
const postControler = require ('../controller/postControler')
const router = express.Router()

router.get('/', (req,res) =>{
    res.json({
        masseg: User.name
    })
})
router.post('/account/register',userValidationResult(), vaidate ,userControler.register)
router.post('/account/login', userControler.login)
router.get('/account/profile',isLoggedIn,userControler.getProfile)
router.put('/account/profile/upload-photo',upload.single('avatar'), isLoggedIn, userControler.uploadUserPhoto)
router.put('/account/profile/update' , upload.array('postImage', 5), validationResulltUpdate() ,vaidate, isLoggedIn, userControler.updateProfil)


// اضافة منشور جديد
router.post('/posts/create' ,validationResultPost(), vaidate,isLoggedIn, postControler.newPost)
router.get('/posts', isLoggedIn , postControler.getAllPost)
module.exports= router