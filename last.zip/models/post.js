const { Sequelize, DataTypes } = require('sequelize');

const db = require('./database')

const Post = db.define('post', {
    title:{
        type: Sequelize.DataTypes.STRING
    },
    contents:{
        type:Sequelize.DataTypes.STRING
    },
    steps:{
        type:Sequelize.DataTypes.STRING
    },
    country:{
        type:Sequelize.DataTypes.STRING
    },
    region:{
        type:Sequelize.DataTypes.STRING
    }
})
Post.associate = module =>{
    Post.belongsTo(module.User)
    Post.hasMany(module.Post_img)
    Post.hasMany(module.Comment)
}
module.exports = Post