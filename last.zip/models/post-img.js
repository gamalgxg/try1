const { Sequelize, DataTypes } = require('sequelize');
const db = require('./database')
const Post_img = db.define('Post_img', {
    img_uri:{
        type:Sequelize.DataTypes.STRING
    } 
}, {
    timestamps:false
})
Post_img.associate = module =>{
    Post_img.belongsTo(module.Post)
}
module.exports = Post_img