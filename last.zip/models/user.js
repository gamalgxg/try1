const { Sequelize, DataTypes } = require('sequelize');

const db = require('./database')
const User = db.define('User', {
    name: {
        type:Sequelize.DataTypes.STRING
    },
    email:{
        type: Sequelize.DataTypes.STRING,
        unique:true
    },
    password: {
        type: Sequelize.DataTypes.STRING
    },
    img_uri: Sequelize.DataTypes.STRING
    
});
User.associate = module =>{
    User.hasMany(module.Post)
    User.hasMany(module.Comment)
}
module.exports = User;