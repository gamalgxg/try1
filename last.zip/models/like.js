const { Sequelize, DataTypes } = require('sequelize');
const db = require('./database')
const Like = db.define('Like', {},{
    timestamps:false
});
Like.associate = module =>{
   module.User.belongsToMany(module.Post,{through:'Like'})
   module.Post.belongsToMany(module.User,{through:'Like'})
}
module.exports =Like