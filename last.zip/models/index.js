const { Sequelize } = require('sequelize');
const User = require('./user');
const Post = require('./post');
const db = require ('./database');
const Post_img = require('./post-img')
const Comment = require('./comment')
const Like = require('./like')
const models = {
    User: User,
    Post:Post,
    Post_img:Post_img,
    Comment:Comment,
    Like:Like
}
Object.keys(models).forEach(key =>{
    if('associate' in models[key]){
        models[key].associate(models)
    }
})
module.exports = models