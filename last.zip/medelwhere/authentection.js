const jwt = require('jsonwebtoken');

const isLoggedIn = (req,res,next) => {
    try {
        const token = req.headers.authorization
        if (!token) {
            res.status(503).json({message: "لم يتم توفير رمز الدخول"});
        }
         else {
            const decoded = jwt.verify(token , process.env.JWT)
            req.currentUser = decoded
            res.status(200).json({ message: "تم تسجيل الدخول"});
            next()
        }
        
    } catch (e)  {
        res.status(500).json(e)
    }
}
module.exports = isLoggedIn